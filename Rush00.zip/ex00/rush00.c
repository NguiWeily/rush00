/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rush00.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: teong <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/06/24 12:36:41 by teong             #+#    #+#             */
/*   Updated: 2023/06/24 14:36:53 by teong            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putchar(char c);

void	ft_printline(int width, char first, char middle, char last)
{
	int	i;

	ft_putchar(first);
	i = 1;
	while (i < width - 1)
	{
		ft_putchar(middle);
		i++;
	}
	if (width > 1)
		ft_putchar(last);
	ft_putchar('\n');
}

void	rush(int x, int y)
{
	int	i;

	if (x <= 0 || y <= 0)
		return ;
	ft_printline(x, 'o', '-', 'o');
	i = 1;
	while (i < y - 1)
	{
		ft_printline(x, '|', ' ', '|');
		i++;
	}
	if (y > 1)
		ft_printline(x, 'o', '-', 'o');
}
